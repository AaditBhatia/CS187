package structures;

public class ScapegoatTree<T extends Comparable<T>> extends BinarySearchTree<T> {
  private int upperBound=0;


  @Override
  public void add(T t){

    if(t==null)
  throw new NullPointerException();
  upperBound=upperBound+1;
  BSTNode<T> newNode=null;
  BSTNode<T> child=null;
  BSTNode<T> parent=null; 
  int height=0;
  double takelog=0.0;

  newNode=new BSTNode<T>(t,null,null);
  root=addToSubtree(root, newNode);
  height=height();
  takelog=Math.log(upperBound)/Math.log((double)3/2);
  if(height()>takelog){

    child=newNode;
    parent=newNode.parent;

    while(3*(double) subtreeSize(child)/2*(double)subtreeSize(parent)<=1){

      parent=parent.parent;
      child=child.parent;

    }
    ScapegoatTree<T> newTree=new ScapegoatTree<T>();
    newTree.root=parent;
    BSTNode<T> tempNode=parent.parent;
    newTree.balance();
    if(tempNode.getRight()==parent)
    tempNode.setRight(newTree.root);
    else
    tempNode.setLeft(newTree.root);

  }

  }
  


 

  @Override
  public boolean remove(T element) {
    if(element==null)
    throw new NullPointerException();
    if(!contains(element)){

      return false;
    }
    else{

      super.remove(element);

    }
    if(upperBound>2*(this.size())){

      this.balance();
      upperBound=this.size();

    }
    return true;
    
  }

  public static void main(String[] args) {
    BSTInterface<String> tree = new ScapegoatTree<String>();
    /*
    You can test your Scapegoat tree here.
    for (String r : new String[] {"0", "1", "2", "3", "4"}) {
      tree.add(r);
      System.out.println(toDotFormat(tree.getRoot()));
    }
    */
  }
}
