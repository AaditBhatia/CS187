package evaluator.arith;

import language.Operand;
import language.Operator;
import parser.IllegalPostfixExpressionException;
import parser.PostfixParser.Type;
import parser.Token;
import parser.arith.ArithPostfixParser;
import stack.LinkedStack;
import stack.StackInterface;
import evaluator.PostfixEvaluator;

/** An {@link ArithPostfixEvaluator} is a postfix evaluator over simple arithmetic expressions. */
public class ArithPostfixEvaluator implements PostfixEvaluator<Integer> {

  private final StackInterface<Operand<Integer>> stack;
  Operand<Integer> first;
  Operand<Integer> second;
  Integer toBeReturned;
  /** Constructs an {@link ArithPostfixEvaluator} */
  public ArithPostfixEvaluator() {
    stack=new LinkedStack<>();
  }

  /** {@inheritDoc} */
  @Override
  public Integer evaluate(String expr) throws IllegalPostfixExpressionException {
    ArithPostfixParser parser = new ArithPostfixParser(expr);
    Operand<Integer> ans;


    for (Token<Integer> token : parser) {
      Type type = token.getType();
      switch (type) {
        case OPERAND:
          stack.push(token.getOperand());
          break;
        case OPERATOR:
         Operator<Integer> operator = token.getOperator();
         if(!operator.toString().equals("!")){
           first=stack.pop();
           second=stack.pop();

           operator.setOperand(0, second);
           operator.setOperand(1, first);
           ans= operator.performOperation();
           stack.push(ans);
           
       }
       else{
         second=stack.pop();
         operator.setOperand(0, second);
         ans= operator.performOperation();
         stack.push(ans);
         
       }
       toBeReturned=ans.getValue();
         


          break;
        default:
          throw new IllegalStateException("Parser returned an invalid Type: " + type);
      }
    }
    if(stack.size()>1)
    throw new IllegalPostfixExpressionException();
    
    return stack.pop().getValue();
  }
}
