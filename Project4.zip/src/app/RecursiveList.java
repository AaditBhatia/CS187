package app;

import java.util.Iterator;

public class RecursiveList<T> implements ListInterface<T>{

  private int size;
  private Node<T> head = null;
 
  

  public RecursiveList() {
    this.head = null;
    this.size = 0;
  }

  public RecursiveList(Node<T> first) {
    this.head = first;
    this.size = 1;
  }

 

  @Override
  public int size() {
        
    return size;
  }
  

  @Override
  public void insertFirst(T elem) {

    Node<T> nN=new Node<T>(elem,null);
    Node<T> tN=new Node<T>(elem, null);
    if(elem==null)
    throw new NullPointerException();
    
    if(head!=null)
    {
      tN=head;
      head=nN;
      head.setNext(tN);
    }
    else{ 
      head=nN;
      head.setNext(null);
    }
    size++;

  }
 


  @Override
  public void insertLast(T elem) {
      
      Node<T> nN=new Node<T>(elem,null);
      if(elem==null)
      throw new NullPointerException();

      if(isEmpty()){
        head=nN;
        size++;
      }
      else{
       insertLast(head, nN);
      
      }

  }
  private void insertLast(Node<T> top, Node<T> newNode) {
    if(top.getNext()==null) {
      top.setNext(newNode);  
      size++;   
    }
    insertLast(top.getNext(),newNode);
  }

  @Override
  public void insertAt(int index, T elem) {
    
    if(elem==null)
    throw new NullPointerException();
    if(index<0||index>size())
    throw new IndexOutOfBoundsException();
    insertRecursion(new Node<T>(elem,null), head, index,0);

  }
  private void insertRecursion(Node<T> newNode, Node<T> t, int ind,int i){
    if(ind==0) {
      insertFirst(newNode.getData());
    }
    else{
      if(i<ind-1){
        if(t!=null)
        insertRecursion(newNode,t.getNext(),ind,i+1);
        newNode.setNext(t.getNext());
        t.setNext(newNode);
        size++;
      }
      else
      throw new NullPointerException();
    }

  }


  @Override
  public T removeFirst() {
    if(head==null)
    throw new IllegalStateException();

    T removedItem = null;
    Node<T> temporary=head;
    head=head.getNext();
    removedItem=temporary.getData();
    size--;

    return removedItem;
  }

  @Override
  public T removeLast() {
    if(head==null)
    throw new IllegalStateException();
    return removeRecursion(size-1, head, head,0);
  }

  @Override
  public T removeAt(int i) {
    if(i<0||i>=size())
    throw new IndexOutOfBoundsException();
    return removeRecursion(i, head, head ,0);
  }
  private T removeRecursion(int i, Node<T> tR, Node<T> t, int j){
    T tbr=head.getData();
    if(i==0){
      size--;
      tbr=head.getData();
      head=head.getNext();
      return tbr;
    }
    else if(i!=1&&j==i){
    t.setNext(tR.getNext());
    tbr=tR.getData();
    tR.setNext(null);
    size--;
    return tbr;  
    }
    else if(i==1){
      tbr=get(1);
      head.setNext(head.getNext().getNext());
      size--;
      return tbr;
    }
    else{
      return removeRecursion(i,tR.getNext(),tR,j+1);
    }
    
    }
    

  @Override
  public T getFirst() {
    if(head==null)
    throw new IllegalStateException();
    return get(0);

  }

  @Override
  public T getLast() {
    
    if(isEmpty())
    throw new IllegalStateException();
    return get(size-1);
  }
 

  @Override
  public T get(int i) {
    if(i<0||i>=size)
    throw new IndexOutOfBoundsException();
    if(isEmpty())
    throw new IllegalStateException();
    return getRecursion(i,0,head);
  }
  private T getRecursion(int i,int j, Node<T> currentNode) {
    
      if(i==j){
        return currentNode.getData();
      }
      return getRecursion(i,1+j,currentNode.getNext());
    

  }

  @Override
  public void remove(T elem) {
    if(head==null||elem==null)
    throw new ItemNotFoundException();
    int len=getI(head, elem, 0);
    if(len==-1||get(len)==null)
    throw new ItemNotFoundException();
    else
    removeAt(len);
    

  }
  private int getI(Node<T> currentNode, T elem, int i){
    if(currentNode.getData()==elem)
    return i;
    if(currentNode==null||currentNode.getNext()==null)
     return -1;
    else
    return getI(currentNode.getNext(),elem,i+1);
  }
    
  @Override
  public int indexOf(T elem) {
    int index ;
    if(elem==null)
    throw new NullPointerException();
    return getI(head,elem,0);
  }
  
  @Override
  public boolean isEmpty() {
    boolean empty = false;
    return size==0;
  }

  public void mystery(int v, Node<T> n){
     if(n.getNext() == null){
        n.setNext(new Node(v,null)); 
        return; 
      }
      if( n.getData().equals(v)) { 
        mystery(v*2, n.getNext()); 
      }
      mystery(v, n.getNext()); }

  @Override
  public Iterator<T> iterator() {
    // TODO Auto-generated method stub
    return null;
  }

  
}