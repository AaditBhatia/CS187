package graph;
import java.util.ArrayList;
/**
 * This class implements general operations on a graph as specified by UndirectedGraphADT.
 * It implements a graph where data is contained in Vertex class instances.
 * Edges between verticies are unweighted and undirected.
 * A graph coloring algorithm determines the chromatic number. 
 * Colors are represented by integers. 
 * The maximum number of vertices and colors must be specified when the graph is instantiated.
 * You may implement the graph in the manner you choose. See instructions and course material for background.
 */
 
 public class UndirectedUnweightedGraph<T> implements UndirectedGraphADT<T> {
   // private class variables here.
   
   private int MAX_VERTICES;
   private int MAX_COLORS;
   ArrayList<Vertex<T>> vertices;
   boolean[][] isAdjacent;
   int numVertices; 
   int numAdjacent;
   boolean f=false;
   
   /**
    * Initialize all class variables and data structures. 
   */   
   public UndirectedUnweightedGraph (int maxVertices, int maxColors){
      MAX_VERTICES = maxVertices;
      MAX_COLORS = maxColors; 
      isAdjacent = new boolean[MAX_VERTICES][MAX_VERTICES];
      vertices = new ArrayList<Vertex<T>>();

   }

   /**
    * Add a vertex containing this data to the graph.
    * Throws Exception if trying to add more than the max number of vertices.
   */
   public void addVertex(T data) throws Exception {
    
    if(numVertices+1>MAX_VERTICES) throw new Exception();
    numVertices=numVertices+1;
    vertices.add(new Vertex<T>(data));
   }
   
   /**
    * Return true if the graph contains a vertex with this data, false otherwise.
   */   
   public boolean hasVertex(T data){
   
    for(int i = 0; i < vertices.size(); i++){
      T tempData=vertices.get(i).getData();
       if(data.equals(tempData))
       return !f;
       else
       continue;
    }
      return false;
   } 

   /**
    * Add an edge between the vertices that contain these data.
    * Throws Exception if one or both vertices do not exist.
   */   
   public void addEdge(T data1, T data2) throws Exception{
    
    if(!hasVertex(data1)||!hasVertex(data2))
    throw new Exception();
    int pos1 = 0;
    int pos2 = 0;
    for(int i = 0; i < vertices.size(); i++){
      if(vertices.get(i).getData().equals(data1))
      pos1 = i;
      if(vertices.get(i).getData().equals(data2))
      pos2 = i;
    }
    numAdjacent=numAdjacent+1;
    isAdjacent[pos1][pos2] = true;
    isAdjacent[pos2][pos1] = true;
    
   }

   /**
    * Get an ArrayList of the data contained in all vertices adjacent to the vertex that
    * contains the data passed in. Returns an ArrayList of zero length if no adjacencies exist in the graph.
    * Throws Exception if a vertex containing the data passed in does not exist.
   */   
   public ArrayList<T> getAdjacentData(T data) throws Exception{
    
    if(!hasVertex(data)){
       throw new Exception();
    }
    ArrayList<T> temp = new ArrayList<T>();
    int index = 0;
    for(int i = 0; i < vertices.size(); i++){ 
      if(vertices.get(i).getData().equals(data)){
         index = i;
      }
    }
    for(int j = 0; j < vertices.size(); j++){
       if(isAdjacent[index][j] == !f){
          temp.add(vertices.get(j).getData());
       }
    }   
    return temp;
   }
   
   /**
    * Returns the total number of vertices in the graph.
   */   
   public int getNumVertices(){
    
      return numVertices;
   }

   /**
    * Returns the total number of edges in the graph.
   */   
   public int getNumEdges(){
    
      return numAdjacent;
   }

   /**
    * Returns the minimum number of colors required for this graph as 
    * determined by a graph coloring algorithm.
    * Throws an Exception if more than the maximum number of colors are required
    * to color this graph.
   */   
  public int getChromaticNumber() throws Exception{
    
    int highestColorUsed = -1;
    int colorToUse = -1;
    for(Vertex<T> curVert : vertices){
       if(curVert.color == -1){
          colorToUse = getColorToUse(curVert);
          if(colorToUse == -1){
            throw new Exception("Incorrect Color To Use!");
         }
          curVert.color = colorToUse;
          if(colorToUse > highestColorUsed){
             highestColorUsed = colorToUse+1;
          }
       }
    }
      return highestColorUsed;
   }

   private int getColorToUse(Vertex<T> current){
      int colorToUse = -1;
      boolean[] adjColorsUsed = new boolean[MAX_COLORS];
      ArrayList<Vertex<T>> adjVertsList = getAdjacentVertices(current);
      for(int i = 0; i < adjVertsList.size(); i++){
        Vertex<T> tempVertex=adjVertsList.get(i);
         if(tempVertex.getColor()== -1)
         continue;
         else
         adjColorsUsed[tempVertex.getColor()]= !f;
         }
      
      for(int i= 0; i <adjColorsUsed.length; i++){
         if(adjColorsUsed[i]==f){
            colorToUse = i;
            break;
         }
      }
      return colorToUse;
   }

   private ArrayList<Vertex<T>> getAdjacentVertices(Vertex<T> cur){
      int pos = 0;
      ArrayList<Vertex<T>> adjList = new ArrayList<Vertex<T>>();
      for(int i =0; i < vertices.size(); i++){ 
        Vertex<T> tempVertex=vertices.get(i);
        if(cur.getData().equals(tempVertex.getData()))
        pos = i;
        
      }
      for(int i =0; i < vertices.size(); i++){
         if(isAdjacent[pos][i]==!f)
         adjList.add(vertices.get(i));  
      }   
      
      return adjList;
     }
   
   
}